package br.com.nightvision;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.plugin.java.JavaPlugin;

public final class NightVisionPlugin extends JavaPlugin {
    private static final int DURATION_TICKS = 20 * 60 * 60; // 1 hora; renovado ao usar /nv

    @Override
    public void onEnable() {
        getLogger().info("NightVision ativado.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Este comando so pode ser usado por um jogador.");
            return true;
        }

        if (!player.hasPermission("nightvision.use")) {
            player.sendMessage(ChatColor.RED + "Voce nao tem permissao para isso.");
            return true;
        }

        if (args.length > 1) {
            player.sendMessage(ChatColor.YELLOW + "Use: /nv, /nv on ou /nv off");
            return true;
        }

        String action = args.length == 0 ? "toggle" : args[0].toLowerCase();

        if (action.equals("on") || (action.equals("toggle") &&
                !player.hasPotionEffect(PotionEffectType.NIGHT_VISION))) {
            player.addPotionEffect(new PotionEffect(
                    PotionEffectType.NIGHT_VISION,
                    DURATION_TICKS,
                    0,
                    false,
                    false,
                    true
            ));
            player.sendMessage(ChatColor.GREEN + "Visao noturna ativada!");
            return true;
        }

        if (action.equals("off") || action.equals("toggle")) {
            player.removePotionEffect(PotionEffectType.NIGHT_VISION);
            player.sendMessage(ChatColor.RED + "Visao noturna desativada!");
            return true;
        }

        player.sendMessage(ChatColor.YELLOW + "Use: /nv, /nv on ou /nv off");
        return true;
    }
}
