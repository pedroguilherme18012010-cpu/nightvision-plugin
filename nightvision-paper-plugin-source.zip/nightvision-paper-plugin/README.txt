NightVision - plugin Paper

Compatibilidade pretendida: Paper 26.3 / Java 25.
Comandos:
  /nv      alterna a visao noturna
  /nv on   ativa
  /nv off  desativa

Como compilar:
1. Instale JDK 25 e Maven.
2. Abra um terminal na pasta do projeto.
3. Execute: mvn clean package
4. O arquivo sera criado em target/nightvision-1.0.0.jar
5. Envie esse JAR para a pasta plugins do servidor e reinicie.

Observacao:
Este projeto e o codigo-fonte do plugin, ainda precisa ser compilado para gerar o .jar.
O efeito e aplicado pelo servidor, entao funciona para jogadores Java e Bedrock que entram pelo Geyser.
